// Shared sounds for every game: click, tick, win, lose, reward.
// Usage: sfx.play('click'); sfx.muted = true to silence everything.
const sfx = {
  muted: false,
  base: 'sounds/',
  _cache: {},
  play(name, volume = 0.8) {
    if (this.muted) return;
    try {
      let a = this._cache[name];
      if (!a) a = this._cache[name] = new Audio(this.base + name + '.mp3');
      a.volume = volume;
      a.currentTime = 0;
      a.play().catch(() => {}); // browsers block sound until the first user click
    } catch (e) {}
  }
};
