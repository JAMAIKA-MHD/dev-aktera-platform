// Win / lose screens: show the score passed in the URL (?score=4&total=5) and play the sound.
(function () {
  var params = new URLSearchParams(window.location.search);
  var score = parseInt(params.get('score'), 10);
  var total = parseInt(params.get('total'), 10);
  var el = document.getElementById('result-score');
  if (el && !isNaN(score) && !isNaN(total)) el.textContent = 'You scored ' + score + ' out of ' + total + '.';
  var name = document.currentScript.getAttribute('data-sfx');
  if (window.sfx && name) sfx.play(name, 0.7);
})();
