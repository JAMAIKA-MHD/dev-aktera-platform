// Shared by every screen: fit-to-window scaling, spotlights, marquee bulbs,
// confetti (win page) and the animated screen-to-screen transition.
(function () {
  var stage = document.querySelector('.stage');
  var leaving = false;

  function fit() {
    var s = Math.min(window.innerWidth / 1280, window.innerHeight / 720);
    stage.style.transform = 'scale(' + s + ')';
    stage.style.left = (window.innerWidth - 1280 * s) / 2 + 'px';
    stage.style.top = (window.innerHeight - 720 * s) / 2 + 'px';
  }
  fit();
  window.addEventListener('resize', fit);

  function div(cls, parent) {
    var d = document.createElement('div');
    d.className = cls;
    parent.appendChild(d);
    return d;
  }

  // spotlights + lamps
  var fx = document.getElementById('fx');
  var lamps = [235, 367, 504, 650, 797, 933, 1062];
  var colors = ['#ff9a3d', '#6a7bff', '#ffb35c', '#5aa0ff', '#ffb35c', '#6a7bff', '#ff9a3d'];
  lamps.forEach(function (x, i) {
    var b = div('beam', fx);
    b.style.left = (x - 110) + 'px';
    b.style.setProperty('--c', colors[i]);
    b.style.animationDelay = (-i * 0.9).toFixed(2) + 's';
    b.style.animationDuration = (4.2 + (i % 3) * 1.1).toFixed(1) + 's';
    var l = div('lamp', fx);
    l.style.left = (x - 10) + 'px';
    l.style.setProperty('--c', colors[i]);
    l.style.animationDelay = (-i * 0.9).toFixed(2) + 's';
  });

  // marquee bulbs around the frame (rounded rectangle, 52 bulbs)
  var bulbs = document.getElementById('bulbs');
  var W = 800, H = 560, I = 15, R = 55, N = 52;
  var sx = W - 2 * I - 2 * R, sy = H - 2 * I - 2 * R, arc = Math.PI * R / 2;
  var total = 2 * sx + 2 * sy + 4 * arc;
  var parts = [
    { len: sx, at: function (t) { return [I + R + t, I]; } },
    { len: arc, at: function (t) { var a = -Math.PI / 2 + t / R; return [W - I - R + R * Math.cos(a), I + R + R * Math.sin(a)]; } },
    { len: sy, at: function (t) { return [W - I, I + R + t]; } },
    { len: arc, at: function (t) { var a = t / R; return [W - I - R + R * Math.cos(a), H - I - R + R * Math.sin(a)]; } },
    { len: sx, at: function (t) { return [W - I - R - t, H - I]; } },
    { len: arc, at: function (t) { var a = Math.PI / 2 + t / R; return [I + R + R * Math.cos(a), H - I - R + R * Math.sin(a)]; } },
    { len: sy, at: function (t) { return [I, H - I - R - t]; } },
    { len: arc, at: function (t) { var a = Math.PI + t / R; return [I + R + R * Math.cos(a), I + R + R * Math.sin(a)]; } }
  ];
  for (var k = 0; k < N; k++) {
    var d = k * total / N, p = parts[0];
    for (var j = 0; j < parts.length; j++) {
      if (d <= parts[j].len || j === parts.length - 1) { p = parts[j]; break; }
      d -= parts[j].len;
    }
    var xy = p.at(d);
    var bulb = div('bulb', bulbs);
    bulb.style.left = xy[0].toFixed(1) + 'px';
    bulb.style.top = xy[1].toFixed(1) + 'px';
    bulb.style.animationDelay = 'calc(var(--spd) * ' + (-(k / N)).toFixed(3) + ')';
  }

  // confetti (only on the win page)
  var conf = document.getElementById('confetti');
  if (conf) {
    var palette = ['#ffb020', '#ff4d6d', '#7c5cff', '#35d0ff', '#ffffff', '#ffd84a'];
    var rnd = function (i, n) { var x = Math.sin(i * 12.9898 + n * 78.233) * 43758.5453; return x - Math.floor(x); };
    for (var i = 0; i < 44; i++) {
      var c = div('confetti', conf);
      c.style.left = Math.round(rnd(i, 1) * 1260) + 'px';
      c.style.width = (8 + Math.round(rnd(i, 2) * 8)) + 'px';
      c.style.height = (14 + Math.round(rnd(i, 3) * 12)) + 'px';
      c.style.background = palette[i % palette.length];
      c.style.setProperty('--dx', Math.round((rnd(i, 4) - 0.5) * 200) + 'px');
      c.style.animationDelay = (rnd(i, 5) * 2.6).toFixed(2) + 's';
      c.style.animationDuration = (3 + rnd(i, 6) * 2.4).toFixed(2) + 's';
    }
  }

  // go('quiz.html'): old screen blurs out, frame flashes, light sweeps, then the next page loads
  window.go = function (url) {
    if (leaving) return;
    leaving = true;
    var screen = document.querySelector('.screen');
    var frame = document.querySelector('.frame');
    var well = document.querySelector('.well');
    if (screen) screen.classList.add('out');
    if (frame) frame.classList.add('flash');
    var sweep = document.createElement('div');
    sweep.className = 'sweep';
    sweep.setAttribute('aria-hidden', 'true');
    well.insertBefore(sweep, well.firstChild);
    setTimeout(function () { window.location.href = url; }, 420);
  };
  document.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-go]') : null;
    if (t) { e.preventDefault(); if (window.sfx) sfx.play('click', 0.6); window.go(t.getAttribute('data-go')); }
  });
})();
