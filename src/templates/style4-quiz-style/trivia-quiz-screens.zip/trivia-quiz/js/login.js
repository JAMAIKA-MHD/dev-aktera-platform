// Login screen: the button shows bouncing dots for a second, then moves to the quiz.
(function () {
  var btn = document.getElementById('login-btn');
  var busy = false;
  btn.addEventListener('click', function () {
    if (busy) return;
    busy = true;
    btn.disabled = true;
    if (window.sfx) sfx.play('click', 0.6);
    btn.innerHTML = '<span aria-label="Loading"><span class="dotl"></span><span class="dotl"></span><span class="dotl"></span></span>';
    setTimeout(function () { window.go('quiz.html'); }, 1000);
  });
})();
