// Quiz screen. Edit the questions here: t = question, o = four answers, a = index of the right answer (0 = A).
(function () {
  var QUESTIONS = [
    { t: 'What is the capital of Algeria?', o: ['Oran', 'Algiers', 'Constantine', 'Annaba'], a: 1 },
    { t: 'Which planet is known as the Red Planet?', o: ['Venus', 'Jupiter', 'Mars', 'Mercury'], a: 2 },
    { t: 'How many continents are there?', o: ['5', '6', '8', '7'], a: 3 },
    { t: 'What is the largest ocean on Earth?', o: ['Pacific', 'Atlantic', 'Indian', 'Arctic'], a: 0 },
    { t: 'Who painted the Mona Lisa?', o: ['Michelangelo', 'Leonardo da Vinci', 'Raphael', 'Picasso'], a: 1 }
  ];
  var PASS = 3; // correct answers needed to reach the win screen

  var CHECK = '<svg width="20" height="20" viewBox="0 0 20 20" aria-label="Correct"><path d="M4 10.5 L8.5 15 L16 5.5" fill="none" stroke="#0a2e1a" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></path></svg>';
  var CROSS = '<svg width="20" height="20" viewBox="0 0 20 20" aria-label="Wrong"><path d="M5 5 L15 15 M15 5 L5 15" fill="none" stroke="#3a050b" stroke-width="3" stroke-linecap="round"></path></svg>';

  var q = 0, score = 0, locked = false;
  var elNum = document.getElementById('q-num');
  var elTotal = document.getElementById('q-total');
  var elScore = document.getElementById('q-score');
  var elSteps = document.getElementById('q-steps');
  var elQ = document.getElementById('q-text');
  var elAns = document.getElementById('q-answers');
  var elWrap = document.getElementById('q-wrap');

  elTotal.textContent = QUESTIONS.length;
  QUESTIONS.forEach(function () { var s = document.createElement('div'); s.className = 'step'; elSteps.appendChild(s); });

  function render() {
    var cur = QUESTIONS[q];
    elNum.textContent = q + 1;
    elScore.textContent = score;
    elQ.textContent = cur.t;
    Array.prototype.forEach.call(elSteps.children, function (s, i) {
      s.className = 'step' + (i < q ? ' done' : (i === q ? ' now' : ''));
    });
    elAns.innerHTML = '';
    cur.o.forEach(function (text, i) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'ans';
      b.innerHTML = '<span class="badge"><span>' + 'ABCD'.charAt(i) + '</span></span><span></span>';
      b.lastChild.textContent = text;
      b.addEventListener('click', function () { pick(i); });
      elAns.appendChild(b);
    });
  }

  function pick(i) {
    if (locked) return;
    locked = true;
    var cur = QUESTIONS[q];
    var correct = i === cur.a;
    if (correct) score++;
    elScore.textContent = score;
    Array.prototype.forEach.call(elAns.children, function (b, idx) {
      b.disabled = true;
      var badge = b.firstChild;
      if (idx === cur.a) { b.className = 'ans ok'; badge.innerHTML = CHECK; }
      else if (idx === i) { b.className = 'ans bad'; badge.innerHTML = CROSS; }
      else { b.className = 'ans dim'; }
    });
    if (window.sfx) sfx.play(correct ? 'reward' : 'lose', 0.5);

    if (q >= QUESTIONS.length - 1) {
      setTimeout(function () {
        var page = score >= PASS ? 'win.html' : 'lose.html';
        window.go(page + '?score=' + score + '&total=' + QUESTIONS.length);
      }, 1400);
    } else {
      setTimeout(function () { elWrap.classList.add('qout'); }, 1000);
      setTimeout(function () { q++; locked = false; render(); elWrap.classList.remove('qout'); }, 1320);
    }
  }

  render();
})();
