# GAME NIGHT — cartoon arcade UI (login · spin wheel · win · lost)

Plain HTML + CSS + JS, no build step, no dependencies. The design is 1280×720 and is scaled to fit any window by `js/app.js`.
Fonts (`Press Start 2P`, `Silkscreen`) load from Google Fonts. To work offline, download them and replace the `<link>` in the pages with `@font-face` rules.

## Run

Open `index.html` in a browser, or serve the folder (`npx serve .` or `python3 -m http.server`).

## Two ways to use the screens

| File | What it is |
|---|---|
| `index.html` | The full flow in ONE page: login → wheel → win / lost. All four screens are in the markup, switched with cross-fading transitions. Use this as the app. |
| `screens/login.html`, `wheel.html`, `win.html`, `lost.html` | Each screen alone, with its own background and parts, ready to drop into an existing router/framework. The same transitions play on enter and on leave, then the page navigates to the next screen. Name, spin count and prize are passed through `sessionStorage` (`gn_name`, `gn_spins`, `gn_prize`). |

The markup inside `<section class="scr" id="scr-…">` is identical in both, so you can copy a section into a component.

## Flow

1. **login** — type a name (max 10 chars, uppercased), press START (or Enter) → wheel
2. **wheel** — big red button spins the wheel (4.5 s, 5+ turns, stops on a random segment, pointer ticks) → after 0.9 s goes to **win** (even segments: +100, x2, +500, JACKPOT) or **lost** (odd segments: LOSE)
3. **win** — prize panel shows the won label, confetti, rotating rays. SPIN AGAIN → wheel, MENU → login
4. **lost** — TRY AGAIN → wheel, MENU → login

## Folder map

```
index.html                 full flow (SPA)
screens/*.html             one page per screen
css/styles.css             all styles + keyframes (design tokens at the top as CSS variables)
js/app.js                  flow, wheel spin, confetti, transitions, optional sound hooks
assets/backgrounds/        login.svg  wheel.svg  win.svg  lost.svg   (1280×720 each, one per screen)
assets/svg/                star-4  die-blue-6  die-red-5  die-blue-3  die-red-6  die-cracked  arcade-cabinet  joystick  skyline
assets/sfx/                (empty) put click / tick / win / lose / reward .mp3 here
```

## Backgrounds (what is in each file)

All four share: indigo gradient (#2b1177 → #1b0b57 → #0d0630), two blurred purple glows, twinkling dots and 6 four-point stars, the two-layer night-city skyline.
- `login.svg` — base only
- `wheel.svg` — base + soft lilac spotlight behind the wheel
- `win.svg` — base + gold radial tint
- `lost.svg` — base + dark red radial tint

In `index.html` the four backgrounds are stacked and cross-faded with the `s-<screen>` class on `#game`.

## Parts and where they sit (1280×720 coordinates)

| Part | File | Position / size | Notes |
|---|---|---|---|
| Blue die, six | `die-blue-6.svg` | left 300, top 110, 92px | `.die.d1`, floats continuously |
| Red die, five | `die-red-5.svg` | left 960, top 6, 104px | `.d2` |
| Blue die, three | `die-blue-3.svg` | left 950, top 370, 84px | `.d3` |
| Red die, six | `die-red-6.svg` | left 320, top 500, 100px | `.d4` |
| Arcade cabinet | `arcade-cabinet.svg` | bottom-right, 300px wide | slides out on wheel, sinks and fades on win/lost |
| Joystick | `joystick.svg` (inlined in the pages so the stick can wobble) | bottom-left, 270px wide | same movement; `.joy-stick` group wobbles |
| Cracked die | `die-cracked.svg` | lost screen, 86px | one-time shake |
| Hub star | inline SVG (same path as `star-4.svg`, fill #ffd23f) | wheel center | |

The wheel, rim lights, big red button, pixel panel buttons, input, prize panel, rays and confetti are CSS (see `css/styles.css`).

## Design tokens

Colors: sky #2b1177 / #1b0b57 / #0d0630 · purple #5a2bd0 · lilac #b9a8ff · panel #3b3a5c · cream border #efe9d0 · cyan #7df3ff · gold #ffd23f / #ffe27a · pink #ff4fa3 · lime #8cff5a · red #d7263d / #ff4d6d · blue #2f5fd0
Fonts: titles/buttons `Press Start 2P`, small labels `Silkscreen`
Title: 88px, white, 6px hard shadow #5a2bd0 + soft glow. Win title 84px gold, lost title 84px red.

## Animations (all in `css/styles.css`)

- **Screen transition:** old screen scales down + blurs out (.35 s), a white flash (.75 s), new screen scales in (starting .3 s later); inner elements pop in one after another with classes `p1`–`p4` / `rise`.
- **Buttons:** hover lifts and glows, press sinks; START pulses; big red button pulses idle, sinks when pressed, greys out while spinning.
- **Wheel:** `transition: transform 4.5s cubic-bezier(.12,.62,.08,1)` on `#disc`; pointer wiggles (`.tick`) while spinning; rim lights blink.
- **Background parts:** dice float (`floaty`), stars twinkle, joystick wobbles, cabinet/joystick move per screen via `.s-wheel` / `.s-win` / `.s-lost`.
- `prefers-reduced-motion` turns animations off.

## Hooks for your code

- **Outcome from a server:** `pickSegment()` in `js/app.js` returns the segment index (0–7) the wheel stops on. Replace it with your API result. Segment table is `SEGMENTS` (even = win with a prize label, odd = lose).
- **Spin duration:** `SPIN_SECONDS` at the top of `app.js`.
- **Sounds:** set `SFX_ENABLED = true` and add `assets/sfx/click.mp3`, `tick.mp3`, `win.mp3`, `lose.mp3`, `reward.mp3`. Browsers only allow audio after a click; START provides that in the single-page flow.
- **Prize labels / wheel text:** wheel labels are plain text in the `.lbl` divs; prize text is `data-prize` on the win screen.

## Notes

- The dice, cabinet and joystick are original simple drawings made for this design.
- The pages use `sessionStorage` only for name / spins / prize; everything works if it is blocked.
