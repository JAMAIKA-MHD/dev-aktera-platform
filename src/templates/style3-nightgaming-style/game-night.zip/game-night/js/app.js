/* GAME NIGHT — flow logic. Works in two modes (set by data-mode on #game):
 *   "spa"   → index.html: all four screens in one page, cross-fading transitions
 *   "multi" → screens/*.html: one screen per page, the same transitions, then navigates
 * Player name / last prize are shared between pages through sessionStorage.
 */
(function () {
  'use strict';

  /* ---------------- config ---------------- */
  var SPIN_SECONDS = 4.5;     // wheel spin duration
  var SFX_ENABLED = false;    // set true after adding files in assets/sfx/ (click, tick, win, lose, reward)
  var SEGMENTS = [            // index = segment clockwise from the top; even = win, odd = lose
    { win: true,  label: '+100 PTS' },
    { win: false, label: '' },
    { win: true,  label: 'x2 BONUS' },
    { win: false, label: '' },
    { win: true,  label: '+500 PTS' },
    { win: false, label: '' },
    { win: true,  label: 'JACKPOT!' },
    { win: false, label: '' }
  ];

  /* Replace this with a server call if the outcome must be decided by your backend.
     It must return the segment index 0..7 the wheel should stop on. */
  function pickSegment() { return Math.floor(Math.random() * SEGMENTS.length); }

  /* ---------------- helpers ---------------- */
  var game = document.getElementById('game');
  var MULTI = game.getAttribute('data-mode') === 'multi';
  var BASE = game.getAttribute('data-base') || '';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  function store(k, v) {
    try {
      if (v === undefined) { var raw = sessionStorage.getItem('gn_' + k); return raw === null ? null : JSON.parse(raw); }
      sessionStorage.setItem('gn_' + k, JSON.stringify(v));
    } catch (e) { return null; }
  }

  var state = {
    screen: game.getAttribute('data-screen') || 'login',
    name: store('name') || '',
    spins: store('spins') || 0,
    prize: store('prize') || '',
    rot: 0,
    spinning: false,
    busy: false
  };

  function playerName() { return state.name || 'PLAYER 1'; }

  function sfx(name) {
    if (!SFX_ENABLED) return;
    try { var a = new Audio(BASE + 'assets/sfx/' + name + '.mp3'); a.volume = 0.7; var p = a.play(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
  }

  /* ---------------- scale 1280x720 stage to the window ---------------- */
  function fit() {
    var s = Math.min(window.innerWidth / 1280, window.innerHeight / 720);
    game.style.transform = 'scale(' + s + ')';
  }
  window.addEventListener('resize', fit);
  fit();

  /* ---------------- text bindings ---------------- */
  function paint() {
    $$('[data-name]').forEach(function (el) { el.textContent = playerName(); });
    $$('[data-spins]').forEach(function (el) { el.textContent = state.spins; });
    if (state.prize) $$('[data-prize]').forEach(function (el) { el.textContent = state.prize; });
  }

  /* ---------------- confetti (win screen) ---------------- */
  var CONF_COLORS = ['#ffd23f', '#3be6ff', '#ff4fa3', '#8cff5a', '#ffffff', '#ff7a3d'];
  function buildConfetti() {
    var wrap = $('#confetti');
    if (!wrap) return;
    wrap.innerHTML = '';
    for (var i = 0; i < 36; i++) {
      var r1 = Math.abs(Math.sin(i * 12.9898) * 43758.5453) % 1;
      var r2 = Math.abs(Math.sin(i * 78.233) * 12345.678) % 1;
      var r3 = Math.abs(Math.sin(i * 39.346) * 9876.543) % 1;
      var w = 8 + Math.round(r2 * 10);
      var d = document.createElement('div');
      d.className = 'conf';
      d.style.cssText = 'left:' + (r1 * 100).toFixed(1) + '%;width:' + w + 'px;height:' + (w + 6) + 'px;background:' + CONF_COLORS[i % CONF_COLORS.length] +
        ';animation-duration:' + (2.4 + r3 * 2.2).toFixed(2) + 's;animation-delay:' + (-r2 * 4).toFixed(2) + 's';
      wrap.appendChild(d);
    }
  }
  function clearConfetti() { var w = $('#confetti'); if (w) w.innerHTML = ''; }

  /* ---------------- screen switching ---------------- */
  function flash() {
    var f = document.createElement('div');
    f.className = 'flash';
    game.appendChild(f);
    setTimeout(function () { if (f.parentNode) f.parentNode.removeChild(f); }, 800);
  }

  function showScreen(name) {
    state.screen = name;
    game.className = game.className.replace(/\bs-\w+\b/g, '').trim() + ' s-' + name;
    $$('.scr').forEach(function (s) { s.classList.toggle('on', s.id === 'scr-' + name); });
    if (name === 'win') buildConfetti(); else clearConfetti();
    if (name === 'win') sfx('win');
    if (name === 'lost') sfx('lose');
    if (name === 'win') setTimeout(function () { sfx('reward'); }, 1200);
    if (name === 'wheel') { $('#bigred') && (function (b) { b.className = 'bigred idle'; $('.cap', b).textContent = 'SPIN'; })($('#bigred')); }
    paint();
  }

  function go(next) {
    if (state.busy) return;
    state.busy = true;
    flash();
    if (MULTI) {
      $$('.scr').forEach(function (s) { s.classList.remove('on'); });   // exit animation
      setTimeout(function () { window.location.href = next + '.html'; }, 520);
    } else {
      setTimeout(function () { showScreen(next); state.busy = false; }, 140);
    }
  }

  /* ---------------- actions ---------------- */
  function start() { sfx('click'); store('name', state.name); setTimeout(function () { go('wheel'); }, 220); }
  function replay() { sfx('click'); setTimeout(function () { go('wheel'); }, 180); }
  function menu() { sfx('click'); setTimeout(function () { go('login'); }, 180); }

  function spin() {
    if (state.spinning) return;
    sfx('click');
    var k = pickSegment();
    var seg = SEGMENTS[k];
    var jitter = (Math.random() - 0.5) * 24;
    var extra = ((360 - k * 45) - (state.rot % 360) + 360) % 360;
    state.rot = state.rot + 360 * 5 + extra + jitter;
    state.spinning = true;
    state.spins += 1;
    state.prize = seg.win ? seg.label : '';
    store('spins', state.spins);
    store('prize', state.prize);

    var disc = $('#disc'), ptr = $('#pointer'), btn = $('#bigred');
    disc.style.transition = 'transform ' + SPIN_SECONDS + 's cubic-bezier(.12,.62,.08,1)';
    disc.style.transform = 'rotate(' + state.rot + 'deg)';
    ptr.classList.add('tick');
    btn.className = 'bigred busy';
    $('.cap', btn).textContent = '...';
    paint();

    var ticks = setInterval(function () { sfx('tick'); }, 220);
    setTimeout(function () {
      clearInterval(ticks);
      state.spinning = false;
      ptr.classList.remove('tick');
      setTimeout(function () { go(seg.win ? 'win' : 'lost'); }, 900);
    }, SPIN_SECONDS * 1000 + 100);
  }

  var handlers = { start: start, spin: spin, replay: replay, menu: menu };
  $$('[data-action]').forEach(function (b) {
    b.addEventListener('click', function () { var h = handlers[b.getAttribute('data-action')]; if (h) h(); });
  });

  var input = $('#pname');
  if (input) {
    input.value = state.name;
    input.addEventListener('input', function () {
      state.name = String(input.value || '').toUpperCase().slice(0, 10);
      input.value = state.name;
      store('name', state.name);
    });
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter') start(); });
  }

  /* ---------------- boot ---------------- */
  paint();
  if (state.screen === 'win') buildConfetti();
  // next frame so the entrance transition + pop-in animations play
  setTimeout(function () { var first = $('#scr-' + state.screen); if (first) first.classList.add('on'); }, 40);
})();
